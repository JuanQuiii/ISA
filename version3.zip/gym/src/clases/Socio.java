/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

import java.util.ArrayList;

/**
 *
 * @author 
 */
public class Socio {
    private String ID;
    private String nick;
    private String clave;
    private String telefono;
    private String email;
    private String tipo_cuota;
    private String IBAN;
    private String id_pulsera;

    public Socio(String ID, String nick, String clave, String telefono, String email, String tipo_cuota, String IBAN, String id_pulsera) {
        this.ID = ID;
        this.nick = nick;
        this.clave = clave;
        this.telefono = telefono;
        this.email = email;
        this.tipo_cuota = tipo_cuota;
        this.IBAN = IBAN;
        this.id_pulsera = id_pulsera;
    }
    
    
    public String getID() {
        return ID;
    }

    public String getNick() {
        return nick;
    }

    public String getPassword() {
        return clave;
    }

    public String getTelefono() {
        return telefono;
    }

    public String getEmail() {
        return email;
    }

    public String getTipo_cuota() {
        return tipo_cuota;
    }

    public String getIBAN() {
        return IBAN;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public void setNick(String nick) {
        this.nick = nick;
    }

    public void setPassword(String password) {
        this.clave = clave;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setTipo_cuota(String tipo_cuota) {
        this.tipo_cuota = tipo_cuota;
    }

    public void setIBAN(String IBAN) {
        this.IBAN = IBAN;
    }
    
}

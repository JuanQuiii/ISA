/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

import java.util.ArrayList;

/**
 *
 * @author Usuario
 */
public class Valoracion {
    private int ID;
    private int numSocio;
    private int numInformeValoracion;
    private int idMonitor;
    
    public Valoracion (int ID, int numSocio, int numInformeValoracion, int idMonitor) {
        this.ID = ID;
        this.numSocio = numSocio;
        this.numInformeValoracion = numInformeValoracion;
        this.idMonitor = idMonitor;
        
}

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public int getNumSocio() {
        return numSocio;
    }

    public void setNumSocio(int numSocio) {
        this.numSocio = numSocio;
    }

    public int getNumInformeValoracion() {
        return numInformeValoracion;
    }

    public void setNumInformeValoracion(int numInformeValoracion) {
        this.numInformeValoracion = numInformeValoracion;
    }

    public int getIdMonitor() {
        return idMonitor;
    }

    public void setIdMonitor(int idMonitor) {
        this.idMonitor = idMonitor;
    }

    
}

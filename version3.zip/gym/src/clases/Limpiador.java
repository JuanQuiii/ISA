/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

import java.util.ArrayList;

/**
 *
 * @author enriq
 */
public class Limpiador extends Empleado{
    private String zona_trabajo;
    private ArrayList<String> arrayLimpiador;

    public Limpiador(String dni, String id_empleado, String nombre, String fecha_nacimiento, float salario, int telefono, String turno, String zona_trabajo) {
        super(dni, id_empleado, nombre, fecha_nacimiento, salario, telefono, turno);
        this.zona_trabajo=zona_trabajo;
    }
    
    

    public String getZona_trabajo() {
        return zona_trabajo;
    }

    public void setZona_trabajo(String zona_trabajo) {
        this.zona_trabajo = zona_trabajo;
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

/**
 *
 * @author enriq
 */
public class Empleado {
    protected String dni;
    protected String id_empleado;
    protected String nombre;
    protected String fecha_nacimiento;
    protected float salario;
    protected int telefono;
    protected String turno;
    protected ArrayList<String> arrayEmpleado;
    
    
    public Empleado(String dni, String id_empleado, String nombre, String fecha_nacimiento, float salario, int telefono, String turno){
        this.dni=dni;
        this.id_empleado=id_empleado;
        this.nombre=nombre;
        this.fecha_nacimiento=fecha_nacimiento;
        this.salario=salario;
        this.telefono=telefono;
        this.turno=turno;
    }

    public String getDni() {
        return dni;
    }

    public String getId_empleado() {
        return id_empleado;
    }

    public String getNombre() {
        return nombre;
    }

    public String getFecha_nacimiento() {
        return fecha_nacimiento;
    }

    public float getSalario() {
        return salario;
    }

    public int getTelefono() {
        return telefono;
    }

    public String getTurno() {
        return turno;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public void setId_empleado(String id_empleado) {
        this.id_empleado = id_empleado;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setFecha_nacimiento(String fecha_nacimiento) {
        this.fecha_nacimiento = fecha_nacimiento;
    }

    public void setSalario(float salario) {
        this.salario = salario;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    public void setTurno(String turno) {
        this.turno = turno;
    }
    
}

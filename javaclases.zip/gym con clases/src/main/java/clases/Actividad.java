/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

/**
 *
 * @author 
 */
public class Actividad {
    private String ID;
    private String tipo;
    private String horario;
    private int aforo;
    private String sala;
    private String fecha;
    
    public void Actividad (String ID, String tipo, String horario, int aforo, String sala, String fecha) {
        this.ID = ID;
        this.tipo = tipo;
        this.horario = horario;
        this.aforo = aforo;
        this.sala = sala;
        this.fecha = fecha;
        
    }

    public String getID() {
        return ID;
    }

    public String getTipo() {
        return tipo;
    }

    public String getHorario() {
        return horario;
    }

    public int getAforo() {
        return aforo;
    }

    public String getSala() {
        return sala;
    }

    public String getFecha() {
        return fecha;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }

    public void setAforo(int aforo) {
        this.aforo = aforo;
    }

    public void setSala(String sala) {
        this.sala = sala;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }
    
    
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

/**
 *
 * @author 
 */
public class Usuario {
    private String ID;
    private String nick;
    private String password;
    private String telefono;
    private String email;
    private String tipo_cuota;
    private String IBAN;
    
    public void Usuario(String ID, String nick, String password, String telefono,String email,String tipo_cuota,String IBAN) {
      this.ID = ID;
      this.nick = nick;
      this.password = password;
      this.telefono = telefono;
      this.email = email;
      this.tipo_cuota = tipo_cuota;
      this.IBAN = IBAN;
   }

    public String getID() {
        return ID;
    }

    public String getNick() {
        return nick;
    }

    public String getPassword() {
        return password;
    }

    public String getTelefono() {
        return telefono;
    }

    public String getEmail() {
        return email;
    }

    public String getTipo_cuota() {
        return tipo_cuota;
    }

    public String getIBAN() {
        return IBAN;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public void setNick(String nick) {
        this.nick = nick;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setTipo_cuota(String tipo_cuota) {
        this.tipo_cuota = tipo_cuota;
    }

    public void setIBAN(String IBAN) {
        this.IBAN = IBAN;
    }
    
}

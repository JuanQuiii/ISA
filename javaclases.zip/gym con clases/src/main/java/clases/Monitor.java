/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

/**
 *
 * @author enriq
 */
public class Monitor extends Empleado{
    private String especialidad;

    public Monitor(String dni, String id_empleado, String nombre, String fecha_nacimiento, float salario, int telefono, String turno,String especialidad) {
        super(dni, id_empleado, nombre, fecha_nacimiento, salario, telefono, turno);
        this.especialidad=especialidad;
    }
    

    public String getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

    
    
}
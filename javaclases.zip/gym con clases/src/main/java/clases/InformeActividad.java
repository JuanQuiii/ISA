/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

/**
 *
 * @author nacho
 */
public class InformeActividad {
    private int num_informe;
    private String dni_director;

    public InformeActividad(int num_informe, String dni_director) {
        this.num_informe = num_informe;
        this.dni_director = dni_director;
    }

    public int getNum_informe() {
        return num_informe;
    }

    public void setNum_informe(int num_informe) {
        this.num_informe = num_informe;
    }

    public String getDni_director() {
        return dni_director;
    }

    public void setDni_director(String dni_director) {
        this.dni_director = dni_director;
    }
  
}

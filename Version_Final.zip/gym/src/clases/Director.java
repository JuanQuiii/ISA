/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

import java.util.ArrayList;

/**
 *
 * @author enriq
 */
public class Director extends Empleado {
    
    private ArrayList<String> arrayDirector;

    public Director(String dni, String id_empleado, String nombre, String fecha_nacimiento, float salario, int telefono,String turno) {
        super(dni, id_empleado, nombre, fecha_nacimiento, salario, telefono, turno);
        
    }
    
}
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

import java.util.ArrayList;

/**
 *
 * @author nacho
 */
public class Factura {
    private int num_facura;
    private int num_matricula_Matricula;
    private ArrayList<String> arrayFactura;

    public Factura(int num_facura, int num_matricula_Matricula) {
        this.num_facura = num_facura;
        this.num_matricula_Matricula = num_matricula_Matricula;
    }

    public int getNum_facura() {
        return num_facura;
    }

    public void setNum_facura(int num_facura) {
        this.num_facura = num_facura;
    }

    public int getNum_matricula_Matricula() {
        return num_matricula_Matricula;
    }

    public void setNum_matricula_Matricula(int num_matricula_Matricula) {
        this.num_matricula_Matricula = num_matricula_Matricula;
    }
    
    
   
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

import java.util.ArrayList;

/**
 *
 * @author nacho
 */
public class ServicioAdicional {
    private int id_serv;
    private String nombre;
    private String tipo;
    private String num_informe_informeActividad;
    private ArrayList<String> arrayServicio;

    public ServicioAdicional(int id_serv, String nombre, String tipo, String num_informe_informeActividad) {
        this.id_serv = id_serv;
        this.nombre = nombre;
        this.tipo = tipo;
        this.num_informe_informeActividad = num_informe_informeActividad;
    }

    public int getId_serv() {
        return id_serv;
    }

    public void setId_serv(int id_serv) {
        this.id_serv = id_serv;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getNum_informe_informeActividad() {
        return num_informe_informeActividad;
    }

    public void setNum_informe_informeActividad(String num_informe_informeActividad) {
        this.num_informe_informeActividad = num_informe_informeActividad;
    }
    
}

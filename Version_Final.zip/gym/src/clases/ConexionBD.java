/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

import java.beans.Statement;
import java.lang.reflect.InvocationTargetException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;
/**
 *
 * @author juanq
 */
public class ConexionBD {
    String usuario= "postgres";
    String contraseña = "basedatos";
    String IP = "localhost";
    String bd ="gym";
    String puerto = "5432";
    String cadena = "jdbc:postgresql://"+IP+":"+puerto+"/"+bd;
    Connection conn = null;
    public Connection connect () throws ClassNotFoundException {
        try {
            Class.forName("org.postgresql.Driver");
            conn= DriverManager.getConnection(cadena,usuario,contraseña);
            System.out.println("Conectado");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return conn;
    }
    public void disconnect(){
        try {
            conn.close();
            System.out.println("Desconectado");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        } catch (Exception ex){
            System.out.println(ex.getMessage());
        }
    }
    public ArrayList<Socio> consultarSocios(){
        ArrayList<Socio> array = new ArrayList();
        try {
            java.sql.Statement stmnt =  conn.createStatement();
            //ResultSet rs = stmnt.executeQuery("SELECT * FROM \"usuario\";");
            ResultSet rs = stmnt.executeQuery("select num_socio,nombre,clave,tlf,email,cuenta,id_pulsera,id_entrenador from socio");
            
            System.out.println("Consulta 1.Listado de socios");
            System.out.println("============================");
            
            while(rs.next()){
                
                String var1 =rs.getString("num_socio");
                String var2 =rs.getString("nombre");
                String var3 =rs.getString("clave");
                String var4 =rs.getString("tlf");
                String var5 =rs.getString("email");
                String var6 =rs.getString("cuenta");
                String var7 =rs.getString("id_pulsera");
                String var8 =rs.getString("id_entrenador");
                Socio soc = new Socio(var1,var2,var3,var4,var5,var6,var7,var8);
                array.add(soc);
                
                
            }
            
        } catch (SQLException ex) { System.out.println(ex.getMessage()); }
        
        return array;
    }
    public ArrayList<Entrenador> consultarEntrenadores(){
        ArrayList<Entrenador> array = new ArrayList();
        try {
            java.sql.Statement stmnt =  conn.createStatement();
            //ResultSet rs = stmnt.executeQuery("SELECT * FROM \"usuario\";");
            
            ResultSet rs = stmnt.executeQuery("select dni,nombre,fecha_nac,salario,tlf,id,turno from entrenador");
            
            System.out.println("Consulta 2.Listado de entrenador");
            System.out.println("============================");
            while(rs.next()){
                String var1=rs.getString("dni");
                String var2=rs.getString("nombre");
                String var3=rs.getString("fecha_nac");
                float var4=rs.getFloat("salario");
                int var5=rs.getInt("tlf");
                String var6=rs.getString("id");
                String var7=rs.getString("turno");
                Entrenador ent = new Entrenador(var1,var6,var2,var3,var4,var5,var7);
                array.add(ent);
                            
            }
        } catch (SQLException ex) { System.out.println(ex.getMessage()); }
        return array;
    }
    public ArrayList<Monitor> consultarMonitores(){
        ArrayList<Monitor> array = new ArrayList();
        try {
            java.sql.Statement stmnt =  conn.createStatement();
            //ResultSet rs = stmnt.executeQuery("SELECT * FROM \"usuario\";");
            
            ResultSet rs = stmnt.executeQuery("select dni,nombre,fecha_nac,salario,tlf,id,turno,especialidad from monitor");
            
            System.out.println("Consulta 3.Listado de monitor");
            System.out.println("============================");
            while(rs.next()){
                String var1=rs.getString("dni");
                String var2=rs.getString("nombre");
                String var3=rs.getString("fecha_nac");
                float var4=rs.getFloat("salario");
                int var5=rs.getInt("tlf");
                String var6=rs.getString("id");
                String var7=rs.getString("turno");
                String var8=rs.getString("especialidad");
                Monitor ent = new Monitor(var1,var6,var2,var3,var4,var5,var7,var8);
                array.add(ent);
            }
        } catch (SQLException ex) { System.out.println(ex.getMessage()); }
        return array;
    }
    public ArrayList<Recepcionista> consultarRecepcionista(){
        ArrayList<Recepcionista> array = new ArrayList();
        try {
            java.sql.Statement stmnt =  conn.createStatement();
            //ResultSet rs = stmnt.executeQuery("SELECT * FROM \"usuario\";");
            
            ResultSet rs = stmnt.executeQuery("select dni,nombre,fecha_nac,salario,tlf,id,turno,num_informe_informeactividad from recepcionista");
            
            System.out.println("Consulta 4.Listado de recepcionista");
            System.out.println("============================");
            while(rs.next()){
                String var1=rs.getString("dni");
                String var2=rs.getString("nombre");
                String var3=rs.getString("fecha_nac");
                float var4=rs.getFloat("salario");
                int var5=rs.getInt("tlf");
                String var6=rs.getString("id");
                String var7=rs.getString("turno");
                String var8=rs.getString("num_informe_informeactividad");
                Recepcionista rec = new Recepcionista(var1,var6,var2,var3,var4,var5,var7,var8);
                array.add(rec);

            }
        } catch (SQLException ex) { System.out.println(ex.getMessage()); }
        return array;
    }
    public ArrayList<Cuota> consultarCuota(){
        ArrayList<Cuota> array = new ArrayList();

        try {
            java.sql.Statement stmnt =  conn.createStatement();
            //ResultSet rs = stmnt.executeQuery("SELECT * FROM \"usuario\";");
            
            ResultSet rs = stmnt.executeQuery("select tipo,precio from cuota");
            
            System.out.println("Consulta 5.Listado de cuotas");
            System.out.println("============================");
            while(rs.next()){
                String var1=rs.getString("tipo");
                float var2=rs.getFloat("precio");
                Cuota cuota = new Cuota(var1,var2);
                array.add(cuota);
            }
        } catch (SQLException ex) { System.out.println(ex.getMessage()); }
        return array;
    }
    public ArrayList<Actividad> consultarActividades(){
        ArrayList<Actividad> array = new ArrayList();
        try {
            java.sql.Statement stmnt =  conn.createStatement();
            //ResultSet rs = stmnt.executeQuery("SELECT * FROM \"usuario\";");
            
            ResultSet rs = stmnt.executeQuery("select id_act,horario,aforo,sala,tipo,dni_director,num_informe_informeactividad,id_monitor from actividad");
            
            System.out.println("Consulta 6.Listado de actividades");
            System.out.println("============================");
            while(rs.next()){
                String var1=rs.getString("id_act");
                String var2=rs.getString("tipo");
                String var3=rs.getString("horario");
                int var4=rs.getInt("aforo");
                String var5=rs.getString("sala");
                

                Actividad act = new Actividad(var1,var2,var3,var4,var5);
                array.add(act);
                

            }
        } catch (SQLException ex) { System.out.println(ex.getMessage()); }
        return array;
    }
    public ArrayList<Valoracion> consultarValoracion(){
        ArrayList<Valoracion> array = new ArrayList();
        try {
            java.sql.Statement stmnt =  conn.createStatement();
            //ResultSet rs = stmnt.executeQuery("SELECT * FROM \"usuario\";");
            
            ResultSet rs = stmnt.executeQuery("select id_val,num_socio_socio,num_informe_informevaloracion,id_monitor from valoracion");
            
            System.out.println("Consulta 7.Listado de valoraciones");
            System.out.println("============================");
            while(rs.next()){
                int var1=rs.getInt("id_val");
                int var2=rs.getInt("num_socio_socio");
                int var3=rs.getInt("num_informe_informevaloracion");
                int var4=rs.getInt("id_monitor");
                Valoracion val = new Valoracion(var1,var2,var3,var4);
                array.add(val);
            }
        } catch (SQLException ex) { System.out.println(ex.getMessage()); }
        return array;
    }
    public ArrayList<ServicioAdicional> consultarServicio(){
        ArrayList<ServicioAdicional> array = new ArrayList();
        try {
            java.sql.Statement stmnt =  conn.createStatement();
            //ResultSet rs = stmnt.executeQuery("SELECT * FROM \"usuario\";");
            
            ResultSet rs = stmnt.executeQuery("select id_serv,nombre,tipo,num_informe_informeactividad from servicioadicional");
            
            System.out.println("Consulta 8.Listado de Servicios Adicionales");
            System.out.println("============================");
            while(rs.next()){
                int var1=rs.getInt("id_serv");
                String var2=rs.getString("nombre");
                String var3=rs.getString("tipo");
                String var4=rs.getString("num_informe_informeactividad");
                ServicioAdicional ser = new ServicioAdicional(var1,var2,var3,var4);
                array.add(ser);            }
        } catch (SQLException ex) { System.out.println(ex.getMessage()); }
        return array;
    }
    public Director consultarDirector(){
        Director dir=null;
        try {
            java.sql.Statement stmnt =  conn.createStatement();
            //ResultSet rs = stmnt.executeQuery("SELECT * FROM \"usuario\";");
            ResultSet rs = stmnt.executeQuery("select dni,nombre,fecha_nac,salario,tlf from director");
            
            System.out.println("Consulta Director");
            System.out.println("============================");
            
            while(rs.next()){
                
                String var1=rs.getString("dni");
                String var2=rs.getString("nombre");
                String var3=rs.getString("fecha_nac");
                float var4=rs.getFloat("salario");
                int var5=rs.getInt("tlf");
                dir = new Director(var1,"DIRECTOR",var2,var3,var4,var5,null);
            }
            
        } catch (SQLException ex) { System.out.println(ex.getMessage()); }
        
        return dir;
    }
    public ArrayList<Limpiador> consultarLimpiadores(){
        ArrayList<Limpiador> array = new ArrayList();
        try {
            java.sql.Statement stmnt =  conn.createStatement();
            //ResultSet rs = stmnt.executeQuery("SELECT * FROM \"usuario\";");
            
            ResultSet rs = stmnt.executeQuery("select dni,nombre,fecha_nac,salario,tlf,id,turno,zona_trabajo from limpiador");
            
            System.out.println("Consulta 4.Listado de recepcionista");
            System.out.println("============================");
            while(rs.next()){
                String var1=rs.getString("dni");
                String var2=rs.getString("nombre");
                String var3=rs.getString("fecha_nac");
                float var4=rs.getFloat("salario");
                int var5=rs.getInt("tlf");
                String var6=rs.getString("id");
                String var7=rs.getString("turno");
                String var8=rs.getString("zona_trabajo");
                Limpiador lim = new Limpiador(var1,var6,var2,var3,var4,var5,var7,var8);
                array.add(lim);

            }
        } catch (SQLException ex) { System.out.println(ex.getMessage()); }
        return array;
    }
    public ArrayList<Empleado> consultarEmpleado(){
        ArrayList<Empleado> array = new ArrayList();
        try {
            java.sql.Statement stmnt =  conn.createStatement();
            //ResultSet rs = stmnt.executeQuery("SELECT * FROM "usuario";");

            ResultSet rs = stmnt.executeQuery("select dni,nombre,fecha_nac,salario,tlf,turno from empleado");

            System.out.println("Consulta 4.Listado de recepcionista");
            System.out.println("============================");
            while(rs.next()){
                String var1=rs.getString("dni");
                String var2=rs.getString("nombre");
                String var3=rs.getString("fecha_nac");
                float var4=rs.getFloat("salario");
                int var5=rs.getInt("tlf");
                String var6=rs.getString("turno");

                Empleado emp = new Empleado(var1,null,var2,var3,var4,var5,var6);
                array.add(emp);

            }
        } catch (SQLException ex) { System.out.println(ex.getMessage()); }
        return array;
    }
    public boolean registrarSocio(String nick, String clave, String telefono, String email, String IBAN){
        String max_id="";
        String max_id_pulsera="";
        String iban_max="";
        try {
            
            java.sql.Statement stmnt =  conn.createStatement();
            System.out.println("Registrar socios");
            System.out.println("============================");
            //ResultSet rs = stmnt.executeQuery("SELECT * FROM "usuario";");
            ResultSet rs = stmnt.executeQuery("SELECT MAX(num_socio) AS IDMAXIMO FROM socio");
            System.out.println(""+rs.getString("IDMAXIMO"));
            ResultSet rs2 = stmnt.executeQuery("SELECT MAX(ID_pulsera) AS IDMAXIMO FROM socio");
            while(rs.next()){
                max_id=rs.getString("id");
            }
            while(rs2.next()){
                max_id_pulsera=rs2.getString("id");
            }
            int id=Integer.parseInt(max_id);
            int id_pulsera=Integer.parseInt(max_id_pulsera);
            String sentenciaSQL=new String();
            sentenciaSQL="insert into socio(num_socio,nombre,clave,tlf,email,cuenta,id_pulsera,id_entrenador)";
            sentenciaSQL+=" values ("+String.valueOf(id+1)+", "+"'"+nick+"'"+", "+"'"+clave+"'"+", "+telefono+", "+"'"+email+"'"+", "+IBAN+", "+String.valueOf(id_pulsera+1)+", "+"2);";
            stmnt.executeUpdate(sentenciaSQL);
            ResultSet rs4 = stmnt.executeQuery("SELECT MAX(num_socio) AS IDMAXIMO,IBAN FROM socio");
            while(rs4.next()){
                iban_max=rs4.getString("IBAN");
            }
            
                
            
        }catch (SQLException ex) { System.out.println(ex.getMessage()); }
        
        if(iban_max.equals(IBAN)){
            return true;
        }
        else{
            return false;
        }
    }
}

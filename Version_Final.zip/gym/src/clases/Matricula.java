/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

import java.util.ArrayList;

/**
 *
 * @author nacho
 */
public class Matricula {
    private int num_matricula;
    private int num_socio_Socio;
    private String tipo_cuota;
    private ArrayList<String> arrayMatricula;

    public Matricula(int num_matricula, int num_socio_Socio, String tipo_cuota) {
        this.num_matricula = num_matricula;
        this.num_socio_Socio = num_socio_Socio;
        this.tipo_cuota = tipo_cuota;
    }

    public int getNum_matricula() {
        return num_matricula;
    }

    public void setNum_matricula(int num_matricula) {
        this.num_matricula = num_matricula;
    }

    public int getNum_socio_Socio() {
        return num_socio_Socio;
    }

    public void setNum_socio_Socio(int num_socio_Socio) {
        this.num_socio_Socio = num_socio_Socio;
    }

    public String getTipo_cuota() {
        return tipo_cuota;
    }

    public void setTipo_cuota(String tipo_cuota) {
        this.tipo_cuota = tipo_cuota;
    }
    
    
}

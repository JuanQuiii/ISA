/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clases;

import clases.ConexionBD;
/**
 *
 * @author juanq
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws ClassNotFoundException {
        ConexionBD app = new ConexionBD();
        app.connect();
        app.consultarSocios();
        app.consultarEntrenadores();
        app.consultarMonitores();
        app.consultarRecepcionista();
        app.consultarCuota();
        app.consultarActividades();
        app.consultarValoracion();
        app.consultarServicio();
        app.disconnect();
        
        
        
        // TODO code application logic here
    }
    
}

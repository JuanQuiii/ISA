/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

import java.beans.Statement;
import java.lang.reflect.InvocationTargetException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Scanner;
/**
 *
 * @author juanq
 */
public class ConexionBD {
    String usuario= "postgres";
    String contraseña = "juandelasbases";
    String IP = "localhost";
    String bd ="gym";
    String puerto = "5432";
    String cadena = "jdbc:postgresql://"+IP+":"+puerto+"/"+bd;
    Connection conn = null;
    public Connection connect () throws ClassNotFoundException {
        try {
            Class.forName("org.postgresql.Driver");
            conn= DriverManager.getConnection(cadena,usuario,contraseña);
            System.out.println("Conectado");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return conn;
    }
    public void disconnect(){
        try {
            conn.close();
            System.out.println("Desconectando...");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        } catch (Exception ex){
            System.out.println(ex.getMessage());
        }
    }
    public void consultarSocios(){
        
        try {
            java.sql.Statement stmnt =  conn.createStatement();
            //ResultSet rs = stmnt.executeQuery("SELECT * FROM \"usuario\";");
            
            ResultSet rs = stmnt.executeQuery("select nombre from socio");
            
            System.out.println("Consulta 1.Listado de socios");
            System.out.println("============================");
            while(rs.next()){
                System.out.println(""+rs.getString("nombre"));
            }
        } catch (SQLException ex) { System.out.println(ex.getMessage()); }
    }
    public void consultarEntrenadores(){
        
        try {
            java.sql.Statement stmnt =  conn.createStatement();
            //ResultSet rs = stmnt.executeQuery("SELECT * FROM \"usuario\";");
            
            ResultSet rs = stmnt.executeQuery("select id,nombre from entrenador");
            
            System.out.println("Consulta 2.Listado de entrenador");
            System.out.println("============================");
            while(rs.next()){
                System.out.println("*");
                System.out.println("NOMBRE:"+rs.getString("nombre"));
                System.out.println("ID:"+rs.getString("id"));
            }
        } catch (SQLException ex) { System.out.println(ex.getMessage()); }
    }
    public void consultarMonitores(){
        
        try {
            java.sql.Statement stmnt =  conn.createStatement();
            //ResultSet rs = stmnt.executeQuery("SELECT * FROM \"usuario\";");
            
            ResultSet rs = stmnt.executeQuery("select id,nombre,especialidad,turno from monitor");
            
            System.out.println("Consulta 3.Listado de monitor");
            System.out.println("============================");
            while(rs.next()){
                System.out.println("*");
                System.out.println("NOMBRE:"+rs.getString("nombre"));
                System.out.println("ID:"+rs.getString("id"));
                System.out.println("ESPECIALIDAD:"+rs.getString("especialidad"));
                System.out.println("TURNO:"+rs.getString("turno"));

            }
        } catch (SQLException ex) { System.out.println(ex.getMessage()); }
    }
    public void consultarRecepcionista(){
        
        try {
            java.sql.Statement stmnt =  conn.createStatement();
            //ResultSet rs = stmnt.executeQuery("SELECT * FROM \"usuario\";");
            
            ResultSet rs = stmnt.executeQuery("select id,nombre,turno from recepcionista");
            
            System.out.println("Consulta 4.Listado de recepcionista");
            System.out.println("============================");
            while(rs.next()){
                System.out.println("*");
                System.out.println("NOMBRE:"+rs.getString("nombre"));
                System.out.println("ID:"+rs.getString("id"));
                System.out.println("TURNO:"+rs.getString("turno"));

            }
        } catch (SQLException ex) { System.out.println(ex.getMessage()); }
    }
    public void consultarCuota(){
        
        try {
            java.sql.Statement stmnt =  conn.createStatement();
            //ResultSet rs = stmnt.executeQuery("SELECT * FROM \"usuario\";");
            
            ResultSet rs = stmnt.executeQuery("select tipo,precio from cuota");
            
            System.out.println("Consulta 5.Listado de cuotas");
            System.out.println("============================");
            while(rs.next()){
                System.out.println("*");
                System.out.println("TIPO:"+rs.getString("tipo"));
                System.out.println("PRECIO:"+rs.getString("precio"));
                

            }
        } catch (SQLException ex) { System.out.println(ex.getMessage()); }
    }
    public void consultarActividades(){
        
        try {
            java.sql.Statement stmnt =  conn.createStatement();
            //ResultSet rs = stmnt.executeQuery("SELECT * FROM \"usuario\";");
            
            ResultSet rs = stmnt.executeQuery("select id_act,horario,aforo,sala,tipo,num_informe_informeactividad,id_monitor from actividad");
            
            System.out.println("Consulta 6.Listado de actividades");
            System.out.println("============================");
            while(rs.next()){
                System.out.println("*");
                System.out.println("ID:"+rs.getString("id_Act"));
                System.out.println("HORARIO:"+rs.getString("horario"));
                System.out.println("AFORO:"+rs.getString("aforo"));
                System.out.println("SALA:"+rs.getString("sala"));
                System.out.println("TIPO:"+rs.getString("tipo"));
                System.out.println("NUMERO DE INFORME:"+rs.getString("num_informe_informeactividad"));
                System.out.println("ID DE SU MONITOR:"+rs.getString("id_monitor"));
                

            }
        } catch (SQLException ex) { System.out.println(ex.getMessage()); }
    }
    public void consultarValoracion(){
        
        try {
            java.sql.Statement stmnt =  conn.createStatement();
            //ResultSet rs = stmnt.executeQuery("SELECT * FROM \"usuario\";");
            
            ResultSet rs = stmnt.executeQuery("select id_val,num_socio_socio,num_informe_informevaloracion,id_monitor from valoracion");
            
            System.out.println("Consulta 7.Listado de valoraciones");
            System.out.println("============================");
            while(rs.next()){
                System.out.println("*");
                System.out.println("ID:"+rs.getString("id_val"));
                System.out.println("SOCIO VALORADOR:"+rs.getString("num_socio_socio"));
                System.out.println("NUMERO DE INFORME:"+rs.getString("num_informe_informevaloracion"));
                System.out.println("MONITOR DE ACTIVIDAD:"+rs.getString("id_monitor"));
                

            }
        } catch (SQLException ex) { System.out.println(ex.getMessage()); }
    }
    public void consultarServicio(){
        
        try {
            java.sql.Statement stmnt =  conn.createStatement();
            //ResultSet rs = stmnt.executeQuery("SELECT * FROM \"usuario\";");
            
            ResultSet rs = stmnt.executeQuery("select id_serv,nombre,tipo,num_informe_informeactividad from servicioadicional");
            
            System.out.println("Consulta 8.Listado de Servicios Adicionales");
            System.out.println("============================");
            while(rs.next()){
                System.out.println("*");
                System.out.println("ID:"+rs.getString("id_serv"));
                System.out.println("NOMBRE:"+rs.getString("nombre"));
                System.out.println("TIPO:"+rs.getString("tipo"));
                System.out.println("NUMERO DE INFORME:"+rs.getString("num_informe_informeactividad"));
                

            }
        } catch (SQLException ex) { System.out.println(ex.getMessage()); }
    }
}
